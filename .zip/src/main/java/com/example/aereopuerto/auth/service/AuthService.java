package com.example.aereopuerto.auth.service;

import com.example.aereopuerto.auth.dto.*;
import com.example.aereopuerto.auth.entity.Role;
import com.example.aereopuerto.auth.entity.User;
import com.example.aereopuerto.auth.repository.UserRepository;
import com.example.aereopuerto.model.Persona;
import com.example.aereopuerto.repository.PersonaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.Random;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PersonaRepository personaRepository;
    private final JwtService jwtService;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final EmailService emailService;

    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        if (Boolean.TRUE.equals(user.getTwoFactorEnabled())) {
            String code = String.format("%06d", new Random().nextInt(999999));
            user.setTwoFactorCode(code);
            userRepository.save(user);
            emailService.sendTwoFactorCode(user.getEmail(), code);
            
            AuthResponse response = new AuthResponse();
            response.setRequires2fa(true);
            response.setEmail(user.getEmail());
            return response;
        }

        String token = jwtService.generateToken(user, user.getId());
        return AuthResponse.builder()
                .token(token)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(user.getPerfilCompleto())
                .requires2fa(false)
                .build();
    }

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }

        Persona persona = new Persona();
        persona.setApellido("Pendiente");
        persona.setSexo(null);
        persona.setIdentificador(null);
        persona.setNombre("Pendiente");
        persona.setNumeroIdentificador(null);
        persona.setFechaNacimiento(null);
        personaRepository.save(persona);

        String verificationToken = UUID.randomUUID().toString();

        User user = User.builder()
                .persona(persona)
                .email(request.getEmail())
                .telefono("Pendiente")
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.ROLE_INCOMPLETO)
                .perfilCompleto(false)
                .isVerified(false)
                .verificationToken(verificationToken)
                .twoFactorEnabled(false)
                .build();

        userRepository.save(user);

        emailService.sendVerificationEmail(user.getEmail(), verificationToken);

        return AuthResponse.builder()
                .token(null)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(user.getPerfilCompleto())
                .requires2fa(false)
                .build();
    }

    public PerfilResponse obtenerPerfil() {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new IllegalArgumentException("Usuario no encontrado"));

        Persona persona = user.getPersona();

        return PerfilResponse.builder()
                .personaId(persona.getId())
                .nombre(persona.getNombre())
                .apellido(persona.getApellido())
                .email(user.getEmail())
                .telefono(user.getTelefono())
                .numeroIdentificador(persona.getNumeroIdentificador())
                .identificador(persona.getIdentificador())
                .fechaNacimiento(persona.getFechaNacimiento())
                .sexo(persona.getSexo())
                .twoFactorEnabled(user.getTwoFactorEnabled())
                .isVerified(user.getIsVerified())
                .role(user.getRole().name())
                .build();
    }

    public List<UsuarioResponse> obtenerUsuarios() {

        List<User> usuarios = userRepository.findAll();

        return usuarios.stream()
                .map(user -> UsuarioResponse.builder()
                        .id(user.getId())
                        .nombre(user.getPersona().getNombre())
                        .apellido(user.getPersona().getApellido())
                        .email(user.getEmail())
                        .telefono(user.getTelefono())
                        .role(user.getRole())
                        .build())
                .toList();
    }

    public UsuarioResponse obtenerUsuario (Integer id)
    {
        User user = userRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Usuario no encontrado"));

        Persona persona = user.getPersona();

        return UsuarioResponse.builder()
                .id(user.getId())
                .nombre(persona.getNombre())
                .apellido(persona.getApellido())
                .email(user.getEmail())
                .telefono(user.getTelefono())
                .role(user.getRole())
                .build();
    }


    public ResponseEntity<AuthResponse> completarPerfil(CompletarPerfilRequest request) {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new IllegalArgumentException("Usuario no encontrado"));

        validarPerfilRequest(request);

        Persona persona = user.getPersona();

        personaRepository.findByNumeroIdentificador(request.getNumeroIdentificador())
                .ifPresent(existing -> {
                    if (!existing.getId().equals(persona.getId())) {
                        throw new IllegalArgumentException("El n\u00famero de documento ya est\u00e1 registrado por otro usuario.");
                    }
                });

        persona.setNombre(request.getNombre());
        persona.setApellido(request.getApellido());
        persona.setNumeroIdentificador(request.getNumeroIdentificador());
        persona.setIdentificador(request.getIdentificador());
        persona.setSexo(request.getSexo());
        persona.setFechaNacimiento(request.getFechaNacimiento());
        user.setTelefono(request.getTelefono());

        user.setPerfilCompleto(true);
        user.setRole(Role.ROLE_USUARIO);

        personaRepository.save(persona);
        userRepository.save(user);

        String nuevoToken = jwtService.generateToken(user, user.getId());
        return ResponseEntity.ok(AuthResponse.builder()
                .token(nuevoToken)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(true)
                .requires2fa(false)
                .build());

    }

    public ResponseEntity<AuthResponse> actualizarPerfil(CompletarPerfilRequest request) {

        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() ->
                        new IllegalArgumentException("Usuario no encontrado"));

        validarPerfilRequest(request);

        Persona persona = user.getPersona();

        personaRepository.findByNumeroIdentificador(request.getNumeroIdentificador())
                .ifPresent(existing -> {
                    if (!existing.getId().equals(persona.getId())) {
                        throw new IllegalArgumentException("El número de documento ya está registrado por otro usuario.");
                    }
                });

        persona.setNombre(request.getNombre());
        persona.setApellido(request.getApellido());
        persona.setNumeroIdentificador(request.getNumeroIdentificador());
        persona.setIdentificador(request.getIdentificador());
        persona.setSexo(request.getSexo());
        persona.setFechaNacimiento(request.getFechaNacimiento());
        user.setTelefono(request.getTelefono());

        user.setPerfilCompleto(true);
        if (user.getRole() == Role.ROLE_INCOMPLETO) {
            user.setRole(Role.ROLE_USUARIO);
        }

        personaRepository.save(persona);
        userRepository.save(user);

        String nuevoToken = jwtService.generateToken(user, user.getId());
        return ResponseEntity.ok(AuthResponse.builder()
                .token(nuevoToken)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(true)
                .requires2fa(false)
                .role(user.getRole().name())
                .build());
    }

    private void validarPerfilRequest(CompletarPerfilRequest request) {
        if (request.getNombre() == null || request.getNombre().isBlank() ||
                request.getApellido() == null || request.getApellido().isBlank() ||
                request.getNumeroIdentificador() == null || request.getNumeroIdentificador().isBlank() ||
                request.getIdentificador() == null ||
                request.getSexo() == null ||
                request.getFechaNacimiento() == null ||
                request.getTelefono() == null || request.getTelefono().isBlank()) {

            throw new IllegalArgumentException(
                    "Todos los campos son obligatorios"
            );
        }
    }

    public AuthResponse verifyEmail(String token) {
        User user = userRepository.findByVerificationToken(token)
                .orElseThrow(() -> new IllegalArgumentException("Token inválido"));

        user.setIsVerified(true);
        user.setVerificationToken(null);
        userRepository.save(user);

        String jwtToken = jwtService.generateToken(user, user.getId());
        return AuthResponse.builder()
                .token(jwtToken)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(user.getPerfilCompleto())
                .requires2fa(false)
                .build();
    }

    public AuthResponse verify2fa(Verify2FARequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        if (!request.getCode().equals(user.getTwoFactorCode())) {
            throw new IllegalArgumentException("Código 2FA incorrecto");
        }

        user.setTwoFactorCode(null);
        userRepository.save(user);

        String token = jwtService.generateToken(user, user.getId());
        return AuthResponse.builder()
                .token(token)
                .email(user.getEmail())
                .userId(user.getId())
                .perfilCompleto(user.getPerfilCompleto())
                .requires2fa(false)
                .build();
    }

    public void forgotPassword(ForgotPasswordRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("No existe una cuenta con ese email"));

        String resetToken = UUID.randomUUID().toString();
        user.setResetToken(resetToken);
        user.setResetTokenExpiry(LocalDateTime.now().plusHours(1));
        userRepository.save(user);

        emailService.sendPasswordResetEmail(user.getEmail(), resetToken);
    }

    public void resetPassword(ResetPasswordRequest request) {
        User user = userRepository.findByResetToken(request.getToken())
                .orElseThrow(() -> new IllegalArgumentException("Token inválido o expirado"));

        if (user.getResetTokenExpiry() == null || user.getResetTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("El token ha expirado. Solicita un nuevo restablecimiento.");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setResetToken(null);
        user.setResetTokenExpiry(null);
        userRepository.save(user);
    }

    public ResponseEntity<String> toggle2fa() {
        String email = SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getName();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        boolean currentStatus = Boolean.TRUE.equals(user.getTwoFactorEnabled());
        user.setTwoFactorEnabled(!currentStatus);
        userRepository.save(user);

        String status = !currentStatus ? "habilitado" : "deshabilitado";
        return ResponseEntity.ok("2FA " + status + " exitosamente.");
    }
}
